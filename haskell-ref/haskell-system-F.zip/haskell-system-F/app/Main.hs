module Main where

import Test.QuickCheck
import SystemFClock

main :: IO ()
main = experiments
